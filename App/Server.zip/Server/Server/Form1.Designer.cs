﻿namespace Server
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.BtnPower = new System.Windows.Forms.Button();
            this.BtnAddRPM = new System.Windows.Forms.Button();
            this.btnDecreaseRPM = new System.Windows.Forms.Button();
            this.btnRemoveSensor = new System.Windows.Forms.Button();
            this.lblSpeed = new System.Windows.Forms.Label();
            this.lblRPM = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblStatus);
            this.panel1.Controls.Add(this.lblSpeed);
            this.panel1.Controls.Add(this.lblRPM);
            this.panel1.Controls.Add(this.btnDecreaseRPM);
            this.panel1.Controls.Add(this.BtnAddRPM);
            this.panel1.Controls.Add(this.BtnPower);
            this.panel1.Location = new System.Drawing.Point(0, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(313, 603);
            this.panel1.TabIndex = 0;
            // 
            // BtnPower
            // 
            this.BtnPower.Location = new System.Drawing.Point(226, 12);
            this.BtnPower.Name = "BtnPower";
            this.BtnPower.Size = new System.Drawing.Size(84, 34);
            this.BtnPower.TabIndex = 0;
            this.BtnPower.Text = "Off/On";
            this.BtnPower.UseVisualStyleBackColor = true;
            // 
            // BtnAddRPM
            // 
            this.BtnAddRPM.Location = new System.Drawing.Point(12, 285);
            this.BtnAddRPM.Name = "BtnAddRPM";
            this.BtnAddRPM.Size = new System.Drawing.Size(84, 34);
            this.BtnAddRPM.TabIndex = 1;
            this.BtnAddRPM.Text = "Increase RPM";
            this.BtnAddRPM.UseVisualStyleBackColor = true;
            // 
            // btnDecreaseRPM
            // 
            this.btnDecreaseRPM.Location = new System.Drawing.Point(12, 337);
            this.btnDecreaseRPM.Name = "btnDecreaseRPM";
            this.btnDecreaseRPM.Size = new System.Drawing.Size(84, 34);
            this.btnDecreaseRPM.TabIndex = 2;
            this.btnDecreaseRPM.Text = "Decrease RPM";
            this.btnDecreaseRPM.UseVisualStyleBackColor = true;
            // 
            // btnRemoveSensor
            // 
            this.btnRemoveSensor.Location = new System.Drawing.Point(482, 581);
            this.btnRemoveSensor.Name = "btnRemoveSensor";
            this.btnRemoveSensor.Size = new System.Drawing.Size(191, 34);
            this.btnRemoveSensor.TabIndex = 3;
            this.btnRemoveSensor.Text = "Remove Selected Sensor";
            this.btnRemoveSensor.UseVisualStyleBackColor = true;
            // 
            // lblSpeed
            // 
            this.lblSpeed.AutoSize = true;
            this.lblSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSpeed.Location = new System.Drawing.Point(9, 222);
            this.lblSpeed.Name = "lblSpeed";
            this.lblSpeed.Size = new System.Drawing.Size(92, 20);
            this.lblSpeed.TabIndex = 4;
            this.lblSpeed.Text = "Fan Speed:";
            // 
            // lblRPM
            // 
            this.lblRPM.AutoSize = true;
            this.lblRPM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblRPM.Location = new System.Drawing.Point(103, 222);
            this.lblRPM.Name = "lblRPM";
            this.lblRPM.Size = new System.Drawing.Size(18, 20);
            this.lblRPM.TabIndex = 5;
            this.lblRPM.Text = "a";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblStatus.Location = new System.Drawing.Point(9, 176);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(92, 20);
            this.lblStatus.TabIndex = 6;
            this.lblStatus.Text = "Fan Status:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(103, 176);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "a";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 627);
            this.Controls.Add(this.btnRemoveSensor);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblSpeed;
        private System.Windows.Forms.Label lblRPM;
        private System.Windows.Forms.Button btnDecreaseRPM;
        private System.Windows.Forms.Button BtnAddRPM;
        private System.Windows.Forms.Button BtnPower;
        private System.Windows.Forms.Button btnRemoveSensor;
    }
}

